#include <Communication/Communication.hpp>
#include <Exploit/TeleportHandler/TeleportHandler.hpp>
#include <Exploit/Common/Log.hpp>
#include <Visuals/Render/Render.hpp>

#include <Windows.h>

static void ModuleMain()
{
    LogInit();
    Communication::Initialize();
    TeleportHandler::Initialize();
    Render::Initialize();
}

static DWORD WINAPI ModuleThread(void*)
{
    __try
    {
        ModuleMain();
    }
    __except (EXCEPTION_EXECUTE_HANDLER)
    {
    }

    return 0;
}

BOOL APIENTRY DllMain(HMODULE HModule, DWORD UlReasonForCall, LPVOID)
{
    if (UlReasonForCall == DLL_PROCESS_ATTACH)
    {
        DisableThreadLibraryCalls(HModule);

        HANDLE Thread = CreateThread(nullptr, 0, ModuleThread, nullptr, 0, nullptr);

        if (Thread)
        {
            CloseHandle(Thread);
        }
    }

    return TRUE;
}
