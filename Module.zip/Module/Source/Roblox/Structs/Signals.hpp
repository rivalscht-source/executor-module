#pragma once

#include <cstddef>
#include <cstdint>

namespace Signals
{
    struct SignalSlot
    {
        int64_t UnknownZero;
        void* FunctionZero;
        SignalSlot* Next;
        void* Atomic;
        int64_t Signal;
        void* FunctionOne;
        void* SlotWrapper;
        void* SlotWrapperSelf;
        void* SlotWrapperFallbackSelf;
    };

    struct SignalConnectionBridge
    {
        SignalSlot* Slot;
        int64_t SharedReference;
        int64_t UnknownZero;
        int64_t UnknownOne;
    };

    static_assert(offsetof(SignalSlot, Next) == 0x10);
    static_assert(offsetof(SignalSlot, Signal) == 0x20);
    static_assert(offsetof(SignalSlot, SlotWrapper) == 0x30);
    static_assert(offsetof(SignalSlot, SlotWrapperSelf) == 0x38);
    static_assert(offsetof(SignalSlot, SlotWrapperFallbackSelf) == 0x40);
    static_assert(offsetof(SignalConnectionBridge, Slot) == 0x0);
}
