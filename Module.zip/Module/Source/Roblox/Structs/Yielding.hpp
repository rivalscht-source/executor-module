#pragma once

#include <cstddef>
#include <cstdint>

struct lua_State;

namespace Roblox
{
    struct YieldState
    {
        uintptr_t State;
        uintptr_t TimeUsed;
        uintptr_t Reserved;
    };

    struct YieldingLuaThread
    {
        char Padding[0x28];
        lua_State* L;
        int32_t ThreadReference;
        int32_t ObjectIdentifier;
    };

    static_assert(offsetof(YieldingLuaThread, L) == 0x28);
    static_assert(offsetof(YieldingLuaThread, ThreadReference) == 0x30);
    static_assert(sizeof(YieldingLuaThread) == 0x38);
}
