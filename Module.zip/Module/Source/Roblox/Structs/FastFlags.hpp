#pragma once

#include <Roblox/Structs/Common.hpp>

#include <array>
#include <cstddef>
#include <cstdint>

namespace Roblox
{
    enum class FastFlagType : uint8_t
    {
        Unknown,
        String,
        CanonicalBoolean,
        Boolean,
        Integer
    };

    struct FastFlagDataBank
    {
        uintptr_t Reserved;
        uintptr_t Entries;
    };

    struct FastFlagEntryCollection
    {
        uintptr_t First;
        uintptr_t Last;
    };

    struct FastFlagEntry
    {
        uintptr_t Next;
        uintptr_t Previous;
        StringStorage Name;
        uintptr_t Descriptor;
    };

    struct FastFlagDescriptor
    {
        uintptr_t TypeDescriptor;
        std::array<uint8_t, 0xB8> Reserved;
        uintptr_t Value;
        union
        {
            bool Boolean;
            int32_t Integer;
            StringStorage String;
        } Cached;
    };

    struct FastFlagCanonicalBooleanDescriptor
    {
        uintptr_t TypeDescriptor;
        std::array<uint8_t, 0xB8> Reserved;
        StringStorage Value;
        StringStorage Cached;
    };

    static_assert(offsetof(FastFlagDataBank, Entries) == 0x8);
    static_assert(offsetof(FastFlagEntry, Name) == 0x10);
    static_assert(offsetof(FastFlagEntry, Descriptor) == 0x30);
    static_assert(offsetof(FastFlagDescriptor, Value) == 0xC0);
    static_assert(offsetof(FastFlagDescriptor, Cached) == 0xC8);
    static_assert(offsetof(FastFlagCanonicalBooleanDescriptor, Value) == 0xC0);
    static_assert(offsetof(FastFlagCanonicalBooleanDescriptor, Cached) == 0xE0);
}
