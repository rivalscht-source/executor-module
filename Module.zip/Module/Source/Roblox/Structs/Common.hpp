#pragma once

#include <cstddef>
#include <cstdint>
#include <string>

namespace Roblox
{
    struct CompressedBytecodeContainer
    {
        uint8_t PaddingZero[0x10];
        const char* Data;
        uint8_t PaddingOne[0x8];
        size_t Size;
    };

    static_assert(offsetof(CompressedBytecodeContainer, Data) == 0x10);
    static_assert(offsetof(CompressedBytecodeContainer, Size) == 0x20);

    struct StringStorage
    {
        union
        {
            char InlineBuffer[16];
            const char* Pointer;
        } Data;
        size_t Size;
        size_t Capacity;
    };

    static_assert(sizeof(StringStorage) == 0x20);

    enum class GameLoadedState : int32_t
    {
        Uninitialized = 0,
        Loading = 15,
        Loaded = 31
    };

    enum MessageType // Unused
    {
        Output = 0,
        Info = 1,
        Warning = 2,
        Error = 3
    };

    struct TypeHolder
    {
        void(*Construct)(const char*, char*);
        void(*MoveConstruct)(char*, char*);
        void(*Destruct)(char*);
    };

    struct RobloxType
    {
        uintptr_t* VirtualTable;
        std::string* Name;
        uintptr_t PaddingZero[4];
        int TypeIdentifier;
        uintptr_t PaddingOne[2];
    };

    struct Variant
    {
        struct Storage
        {
            const TypeHolder* Holder;
            char Data[64];
        };

        const RobloxType* Type;
        Storage Value;
    };

    enum class EventTargetInclusion : int32_t
    {
        OnlyTarget = 0,
        ExcludeTarget = 1
    };

    struct SystemAddress
    {
        struct PeerIdentifier
        {
            unsigned int Identifier;
        };

        PeerIdentifier RemoteIdentifier;
    };

    struct RemoteEventInvocationTargetOptions
    {
        const SystemAddress* Target;
        EventTargetInclusion IsExcludeTarget;
    };
}
