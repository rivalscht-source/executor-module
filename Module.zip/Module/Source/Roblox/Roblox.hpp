#pragma once

#include <Exploit/Classes/DataModel/DataModel.hpp>
#include <Exploit/Common/Log.hpp>
#include <Roblox/Offsets.hpp>
#include "Structs.hpp"
#include <cstdarg>
#include <cstdint>
#include <excpt.h>
#include <lstate.h>
#include <string>

struct lua_State;

namespace Roblox
{
    inline auto Print = reinterpret_cast<uintptr_t(*)(int, const char*, ...)>(Offsets::Print);

    inline auto ScriptContextResume = reinterpret_cast<uint64_t(__fastcall*)(
        uintptr_t,
        YieldState*,
        YieldingLuaThread**,
        uint32_t,
        uint8_t,
        uintptr_t
        )>(Offsets::Script::ScriptContextResume);

    inline auto GetLuaStateForInstance = reinterpret_cast<uintptr_t(__fastcall*)(uintptr_t, uintptr_t*, uintptr_t*)>(Offsets::GetLuaStateForInstance);
    inline auto GetIdentityStruct = reinterpret_cast<uintptr_t(__fastcall*)(uintptr_t)>(Offsets::Identity::GetIdentityStruct);
    inline auto GetCapabilities = reinterpret_cast<__int64(__fastcall*)(int*)>(Offsets::Identity::GetCapabilities);

    inline auto LuaVMLoad = reinterpret_cast<int(__fastcall*)(lua_State*, const char*, const char*, size_t, int)>(Offsets::Luau::LuaVM_Load);
    inline auto LoadScriptBytecode = reinterpret_cast<int(__fastcall*)(lua_State*, std::string*, const char*, int)>(Offsets::Script::LuaVMLoad);
    inline auto Luau_Execute = reinterpret_cast<void(__fastcall*)(lua_State*)>(Offsets::Luau::Luau_Execute);
    inline auto LuaD_Throw = reinterpret_cast<void(__fastcall*)(lua_State*, int)>(Offsets::Luau::LuaD_Throw);
    inline auto LuaC_Step = reinterpret_cast<uintptr_t(__fastcall*)(lua_State*, bool)>(Offsets::Luau::LuaC_Step);

    inline auto CastArgs = reinterpret_cast<uintptr_t(__fastcall*)(lua_State*, int, void*, bool, int)>(Offsets::Reflection::CastArgs);
    inline auto KTable = reinterpret_cast<uintptr_t*>(Offsets::Reflection::KTable);
    inline auto GetPropertyDataRaw = reinterpret_cast<void* (__fastcall*)(uintptr_t, uintptr_t*, uintptr_t*, int)>(Offsets::Reflection::GetPropertyData);

    inline auto PushInstance = reinterpret_cast<void(__fastcall*)(lua_State*, void**)>(Offsets::Reflection::PushInstance);

    namespace InstanceBridge {
        inline auto UintPtr = (void(__fastcall*)(lua_State*, std::uintptr_t))Offsets::Reflection::PushInstance;
        inline auto Shared = (void(__fastcall*)(lua_State*, std::shared_ptr<std::uintptr_t*>))Offsets::Reflection::PushInstance;
        inline auto Void = (void(__fastcall*)(lua_State*, void**))Offsets::Reflection::PushInstance;
        inline auto Void2 = (void(__fastcall*)(lua_State*, void*))Offsets::Reflection::PushInstance;
        inline auto Weak = (void(__fastcall*)(lua_State*, std::weak_ptr<std::uintptr_t>))Offsets::Reflection::PushInstance;
    }

    namespace Signals {
        inline auto FireProximityPrompt = (uintptr_t * (__thiscall*)(uintptr_t))Offsets::Input::FireProximityPrompt;
        inline auto FireMouseClick = (void(__fastcall*)(__int64, float, __int64))Offsets::Input::FireMouseClick;
        inline auto FireRightMouseClick = (void(__fastcall*)(__int64, float, __int64))Offsets::Input::FireRightMouseClick;
        inline auto FireMouseHoverEnter = (void(__fastcall*)(__int64, __int64))Offsets::Input::FireMouseHoverEnter;
        inline auto FireMouseHoverLeave = (void(__fastcall*)(__int64, __int64))Offsets::Input::FireMouseHoverLeave;
        inline auto FireTouchInterest = (void(__fastcall*)(uintptr_t, uintptr_t, uintptr_t, bool, bool))Offsets::Input::FireTouchInterest;
    }

    namespace Task {
        inline auto Defer = reinterpret_cast<int(__fastcall*)(lua_State*)>(Offsets::Task::Defer);
    }

}
