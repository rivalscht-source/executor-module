#pragma once

#include "Structs.hpp"

#include <cstdint>
#include <cstddef>
#include <Windows.h>

#define REBASE(Address) (Address + reinterpret_cast<uintptr_t>(GetModuleHandleA("RobloxPlayerBeta.exe")))
#define HYPREBASE(Address) (Address + reinterpret_cast<uintptr_t>(GetModuleHandleA("RobloxPlayerBeta.dll")))

namespace Offsets
{
    inline const uintptr_t Print = REBASE(0x470C4E0);
    inline const uintptr_t GetLuaStateForInstance = REBASE(0x1D36CE0);
    inline const uintptr_t OpcodeLookupTable = REBASE(0x62DFFA0);
    inline const uintptr_t ConnectionDisconnect = REBASE(0x1D3E370);

    namespace Task
    {
        inline const uintptr_t Cancel = REBASE(0x1E7B660); // Unused
        inline const uintptr_t Defer = REBASE(0x1E7B970);
        inline const uintptr_t Delay = REBASE(0x1E7BD60); // Unused
        inline const uintptr_t Desynchronize = REBASE(0x1E7BFB0); // Unused
        inline const uintptr_t Spawn = REBASE(0x1E7C850); // Unused
        inline const uintptr_t Synchronize = REBASE(0x1E7C9D0); // Unused
        inline const uintptr_t Wait = REBASE(0x1E7CBD0);
    }

    namespace ExtraSpace
    {
        inline constexpr uintptr_t RequireBypass = 0x909;
        inline constexpr uintptr_t ScriptContextToResume = 0x7D8;
        inline constexpr uintptr_t IsCoreScript = 0x168; // Unused
    }

    namespace DataModel
    {
        inline const uintptr_t FakeDataModelPointer = REBASE(0x7D28508);
        inline constexpr uintptr_t FakeDataModelToDataModel = 0x1D0;
        inline constexpr uintptr_t Children = 0x70;
        inline constexpr uintptr_t ScriptContext = 0x440;
        inline constexpr uintptr_t GameLoaded = 0x578;
        inline constexpr uintptr_t PlaceId = 0x190;
        inline constexpr uintptr_t GameId = 0x188;
        inline constexpr uintptr_t CreatorId = 0x180;
        inline constexpr uintptr_t JobId = 0x120;
        inline constexpr uintptr_t Workspace = 0x160;
    }

    namespace TaskScheduler
    {
        inline const uintptr_t Pointer = REBASE(0x82B9F48);
        inline constexpr uintptr_t JobEnd = 0xd0;
        inline constexpr uintptr_t DetailedJobName = 0x108;
        inline constexpr uintptr_t JobName = 0x18;
        inline constexpr uintptr_t JobStart = 0xc8;
        inline constexpr uintptr_t MaxFPS = 0xb0;
        inline constexpr uintptr_t JobEntryStride = 0x10;
        inline constexpr size_t JobVirtualTableLength = 25;
        inline constexpr size_t JobStepVirtualTableIndex = 1;
    }

    namespace Crash
    {
        inline const uintptr_t RobloxLogCrash = REBASE(0x4AF5220);
    }

    namespace Luau
    {
        inline const uintptr_t Luau_Execute = REBASE(0x47A1E30);
        inline const uintptr_t LuaO_NilObject = REBASE(0x6A4D5E8); // Unused
        inline const uintptr_t LuaH_DummyNode = REBASE(0x6A4D478); // Unused
        inline const uintptr_t LuaVM_Load = REBASE(0x4795860); // 48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 41 56 41 57 48 81 EC 80 00 00 00 49 8B E9 4D 8B F0
        inline const uintptr_t LuaD_Throw = REBASE(0x478F6A0);
        inline const uintptr_t LuaC_Step = REBASE(0x4793EA0);
    }

    namespace Identity
    {
        inline const uintptr_t Pointer = REBASE(0x82AB098);
        inline const uintptr_t GetIdentityStruct = REBASE(0x47EFFE0);
        inline const uintptr_t GetCapabilities = REBASE(0x47F0430);
        namespace IdentityStruct
        {
            inline constexpr uintptr_t Capabilities = 0x28;
        }
    }

    namespace Input
    {
        inline const uintptr_t FireMouseClick = REBASE(0x266D770);
        inline const uintptr_t FireRightMouseClick = REBASE(0x266DDE0);
        inline const uintptr_t FireMouseHoverEnter = REBASE(0x266D980);
        inline const uintptr_t FireMouseHoverLeave = REBASE(0x266DB70);
        inline const uintptr_t FireTouchInterest = REBASE(0x2ACAF00);
        inline const uintptr_t FireProximityPrompt = REBASE(0x26ADE00);
    }

    namespace Reflection
    {
        inline const uintptr_t PushInstance = REBASE(0x1D29C40);
        inline const uintptr_t KTable = REBASE(0x82BB920);
        inline const uintptr_t CastArgs = REBASE(0x1D18030);
        inline const uintptr_t GetPropertyData = REBASE(0xC9D2A0);
    }

    namespace PropertyDescriptor
    {
        inline constexpr uintptr_t PropertyDescriptorBitFlags = 0x8C;
        inline constexpr uintptr_t ScriptableMask = 0x10;
        inline constexpr uintptr_t TypeDescriptor = 0x68;
        inline constexpr uintptr_t CallbackStorage = 0x80;
    }

    namespace Callback
    {
        inline constexpr uintptr_t Wrapper = 0x18;
        inline constexpr uintptr_t WeakChain = 0x38;
        inline constexpr uintptr_t WeakObject = 0x18;
        inline constexpr uintptr_t Reference = 0x34;
        inline constexpr uintptr_t DataModelAdjustment = 0x1C8;
    }

    namespace SharedString
    {
        inline constexpr uintptr_t Content = 0x10;
    }

    namespace ClassDescriptor
    {
        inline const uintptr_t HashLookup = REBASE(0x4A398F0);
        inline constexpr uintptr_t PropertyMap = 0x250;
        inline constexpr uintptr_t PropertyMapBucketIndices = 0x2C8;
        inline constexpr uintptr_t PropertyMapEntries = 0x2D0;
        inline constexpr uintptr_t PropertyMapBucketMask = 0x2D8;
        inline constexpr uintptr_t PropertyMapEntrySize = 0x10;
        inline constexpr uintptr_t PropertyEntryDescriptor = 0x0;
        inline constexpr uintptr_t PropertyEntryKind = 0x8;
        inline constexpr uint32_t PropertyEntryKindValue = 0;
        inline constexpr uint32_t CallbackEntryKindValue = 4;
    }

    namespace Instance
    {
        inline constexpr uintptr_t ChildrenStart = 0x70;
        inline constexpr uintptr_t ChildrenEnd = 0x8;
        inline constexpr uintptr_t ClassDescriptor = 0x18;
        inline constexpr uintptr_t ClassName = 0x8;
        inline constexpr uintptr_t Name = 0x98;
        inline constexpr uintptr_t Parent = 0x68;
    }

    namespace BasePart
    {
        inline constexpr uintptr_t Primitive = 0x128;
        inline constexpr uintptr_t Overlap = 0x1F0;
    }

    namespace Script
    {
        inline const uintptr_t ScriptContextResume = REBASE(0x1E067F0);

        inline constexpr uintptr_t RunContext = 0x130;

        namespace LocalScript
        {
            inline constexpr uintptr_t ByteCode = 0x190;
            inline constexpr uintptr_t Hash = 0x1A0;
        }

        namespace ModuleScript
        {
            inline constexpr uintptr_t ByteCode = 0x138;
            inline constexpr uintptr_t Hash = 0x148;
        }

        namespace ByteCode
        {
            inline constexpr uintptr_t Pointer = 0x10;
            inline constexpr uintptr_t Size = 0x20;
        }
    }
    
    namespace Render
    {
        inline constexpr uintptr_t RenderJobToView = 0x1D0;
        inline constexpr uintptr_t RenderViewToDevice = 0x8;
        inline constexpr uintptr_t SwapChain = 0xC8;
    }

    namespace SignalConnection
    {
        inline const uintptr_t Disconnect = REBASE(0x4AFA5F0);
        inline const uintptr_t WaitScriptSlotVirtualTable = REBASE(0x5F7DB80);
        inline constexpr uintptr_t Next = 0x10;
        inline constexpr uintptr_t Enabled = 0x20;
        inline constexpr uintptr_t SlotWrapper = 0x30;
        inline constexpr uintptr_t SlotWrapperSelf = 0x38;
        inline constexpr uintptr_t SlotWrapperFallbackSelf = 0x40;
        inline constexpr uintptr_t FunctionScriptSlotSelf = 0x18;
        inline constexpr uintptr_t WeakChain = 0x68;
        inline constexpr uintptr_t WeakChainNext = 0x8;
        inline constexpr uintptr_t SelfWeakFallback = 0x48;
    }

    namespace SignalWeakObject
    {
        inline constexpr uintptr_t Thread = 0x28;
        inline constexpr uintptr_t FunctionReference = 0x34;
        inline constexpr uintptr_t Pointer = 0x60;
        inline constexpr uintptr_t WaitContainer = 0x50;
    }

    namespace Actor
    {
        inline const uintptr_t GetParallel = REBASE(0x1E7FFC0);
        inline constexpr uintptr_t ParallelFlag = 0x50;
    }

    namespace EventInstance
    {
        inline constexpr uintptr_t Descriptor = 0x0;
        inline constexpr uintptr_t OwningInstance = 0x18;
    }

    namespace EventDescriptor
    {
        inline constexpr uintptr_t Signature = 0x48;
    }

    namespace EventSignature
    {
        inline constexpr uintptr_t FirstParameter = 0x8;
        inline constexpr uintptr_t ParameterStride = 0x70;
        inline constexpr size_t MaximumParameters = 128;
    }

    namespace VirtualTable
    {
        inline constexpr uintptr_t RaiseEventInvocation = 0x18;
    }

    namespace Flags
    {
        inline const uintptr_t GetFFlag = REBASE(0x4B27090);
        inline const uintptr_t SetFFlag = REBASE(0x4B2CBC0);
        inline const uintptr_t FlogDataBank = REBASE(0x852A7E8);
        inline const uintptr_t StringTypeDescriptor = REBASE(0x6AD4668);
        inline const uintptr_t CanonicalBooleanTypeDescriptor = REBASE(0x6AD3A68);
        inline const uintptr_t BooleanTypeDescriptor = REBASE(0x6AD3918);
        inline const uintptr_t IntegerTypeDescriptor = REBASE(0x6AD3800);
        inline const uintptr_t LockViolationInstanceCrash = REBASE(0x85B96F8);
        inline const uintptr_t LockViolationScriptCrash = REBASE(0x845BEA8);
    }

    namespace Hyperion // Unused, don't dump these
    {
        inline constexpr uintptr_t ControlFlowGuardianRange = 0x100;
        inline const uintptr_t ControlFlowGuardian = HYPREBASE(0x3E12D0);
        inline const uintptr_t ValidateCandidate = HYPREBASE(0x4200D0);
    }
}
